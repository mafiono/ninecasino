/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package d.c.a.e.w;

import d.c.a.e.w.m;

public class f {
    public void b(float f2, float f3, float f4, m m2) {
        m2.d(f2, 0.0f);
    }
}

