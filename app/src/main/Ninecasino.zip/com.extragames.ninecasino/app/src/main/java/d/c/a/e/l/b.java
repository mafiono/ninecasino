/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.graphics.Canvas
 *  android.graphics.drawable.Drawable
 *  android.widget.FrameLayout
 */
package d.c.a.e.l;

import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.widget.FrameLayout;
import d.c.a.e.l.d;

public class b
extends FrameLayout
implements d {
    @Override
    public void a() {
        throw null;
    }

    @Override
    public void b() {
        throw null;
    }

    @SuppressLint(value={"MissingSuperCall"})
    public void draw(Canvas canvas) {
        super.draw(canvas);
    }

    public Drawable getCircularRevealOverlayDrawable() {
        throw null;
    }

    @Override
    public int getCircularRevealScrimColor() {
        throw null;
    }

    @Override
    public d.e getRevealInfo() {
        throw null;
    }

    public boolean isOpaque() {
        return super.isOpaque();
    }

    @Override
    public void setCircularRevealOverlayDrawable(Drawable drawable) {
        throw null;
    }

    @Override
    public void setCircularRevealScrimColor(int n2) {
        throw null;
    }

    @Override
    public void setRevealInfo(d.e e2) {
        throw null;
    }
}

