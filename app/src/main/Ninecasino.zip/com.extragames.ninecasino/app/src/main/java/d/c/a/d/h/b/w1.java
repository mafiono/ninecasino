/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.d.g.f.fa
 *  d.c.a.d.g.f.ga
 *  d.c.a.d.h.b.j3
 *  java.lang.Object
 */
package d.c.a.d.h.b;

import d.c.a.d.g.f.fa;
import d.c.a.d.g.f.ga;
import d.c.a.d.h.b.j3;

public final class w1
implements j3 {
    public static final j3 a = new w1();

    public final Object a() {
        return ((fa)ga.f.a()).b();
    }
}

