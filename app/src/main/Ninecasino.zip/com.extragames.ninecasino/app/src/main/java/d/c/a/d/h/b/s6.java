/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.text.TextUtils
 *  d.c.a.d.h.b.e6
 *  d.c.a.d.h.b.y9
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package d.c.a.d.h.b;

import android.os.Bundle;
import android.text.TextUtils;
import d.c.a.d.h.b.e6;
import d.c.a.d.h.b.u5;
import d.c.a.d.h.b.w4;
import d.c.a.d.h.b.y9;

public final class s6
implements y9 {
    public final /* synthetic */ e6 a;

    public s6(e6 e62) {
        this.a = e62;
    }

    public final void a(String string, Bundle bundle) {
        if (TextUtils.isEmpty(string)) {
            this.a.H("auto", "_err", bundle);
            return;
        }
        this.a.a.l();
        throw null;
    }
}

