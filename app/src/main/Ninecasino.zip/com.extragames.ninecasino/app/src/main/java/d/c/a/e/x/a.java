/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.material.behavior.SwipeDismissBehavior
 *  java.lang.Object
 */
package d.c.a.e.x;

import com.google.android.material.behavior.SwipeDismissBehavior;

public class a {
    public a(SwipeDismissBehavior<?> swipeDismissBehavior) {
        swipeDismissBehavior.e = SwipeDismissBehavior.C((float)0.0f, (float)0.1f, (float)1.0f);
        swipeDismissBehavior.f = SwipeDismissBehavior.C((float)0.0f, (float)0.6f, (float)1.0f);
        swipeDismissBehavior.c = 0;
    }
}

