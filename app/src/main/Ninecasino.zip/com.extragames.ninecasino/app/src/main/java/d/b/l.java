/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.b.g
 *  java.lang.String
 */
package d.b;

import d.b.g;

public class l
extends g {
    public static final long serialVersionUID = 1L;

    public l(String string) {
        super(string);
    }
}

