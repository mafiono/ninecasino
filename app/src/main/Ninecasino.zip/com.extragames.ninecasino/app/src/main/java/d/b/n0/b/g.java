/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  d.b.n0.b.g$a
 *  d.b.n0.b.h
 *  java.lang.Object
 */
package d.b.n0.b;

import android.os.Parcel;
import android.os.Parcelable;
import d.b.n0.b.g;
import d.b.n0.b.h;

public final class g
extends h<g, Object> {
    public static final Parcelable.Creator<g> CREATOR = new a();

    public g(Parcel parcel) {
        super(parcel);
    }
}

