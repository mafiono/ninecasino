/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.b.j.i
 *  d.c.a.b.j.t.h.q
 *  d.c.a.b.j.t.h.s
 *  d.c.a.b.j.t.i.c
 *  java.lang.Iterable
 *  java.lang.Object
 */
package d.c.a.b.j.t.h;

import d.c.a.b.j.i;
import d.c.a.b.j.t.h.q;
import d.c.a.b.j.t.h.s;
import d.c.a.b.j.t.i.c;
import d.c.a.b.j.u.b;

public final class p
implements b.a {
    public final q a;

    public p(q q2) {
        this.a = q2;
    }

    public Object execute() {
        q q2 = this.a;
        for (i i2 : q2.b.f0()) {
            q2.c.a(i2, 1);
        }
        return null;
    }
}

