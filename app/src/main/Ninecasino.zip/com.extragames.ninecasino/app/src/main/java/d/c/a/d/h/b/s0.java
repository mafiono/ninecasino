/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.d.g.f.p8
 *  d.c.a.d.g.f.q8
 *  d.c.a.d.h.b.j3
 *  java.lang.Object
 */
package d.c.a.d.h.b;

import d.c.a.d.g.f.p8;
import d.c.a.d.g.f.q8;
import d.c.a.d.h.b.j3;

public final class s0
implements j3 {
    public static final j3 a = new s0();

    public final Object a() {
        return ((p8)q8.f.a()).x();
    }
}

