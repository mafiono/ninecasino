/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Path
 *  java.lang.Object
 */
package c.v;

import android.graphics.Path;

public abstract class e {
    public abstract Path a(float var1, float var2, float var3, float var4);
}

