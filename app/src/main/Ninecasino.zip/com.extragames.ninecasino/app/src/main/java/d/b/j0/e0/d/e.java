/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.b.j0.e0.a
 *  d.b.j0.e0.b
 *  java.lang.Integer
 *  java.lang.Object
 *  java.util.LinkedList
 *  java.util.Queue
 */
package d.b.j0.e0.d;

import d.b.j0.e0.a;
import d.b.j0.e0.b;
import java.util.LinkedList;
import java.util.Queue;

public class e
implements b {
    public static e b;
    public static final Integer c;
    public Queue<a> a = new LinkedList();

    public static {
        c = 100;
    }
}

