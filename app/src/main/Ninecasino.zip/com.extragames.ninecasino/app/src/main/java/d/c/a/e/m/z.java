/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.util.TimeZone
 */
package d.c.a.e.m;

import java.util.TimeZone;

public class z {
    public static final z c = new z(null, null);
    public final Long a = null;
    public final TimeZone b = null;

    public z(Long l2, TimeZone timeZone) {
    }
}

