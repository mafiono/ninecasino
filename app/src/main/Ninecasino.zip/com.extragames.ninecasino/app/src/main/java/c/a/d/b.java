/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 */
package c.a.d;

import android.content.Context;

public interface b {
    void a(Context var1);
}

