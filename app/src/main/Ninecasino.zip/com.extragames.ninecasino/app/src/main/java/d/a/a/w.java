/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.b.f0.b
 *  d.b.f0.b$a
 *  g.a.h
 *  java.lang.Object
 */
package d.a.a;

import d.b.f0.b;
import g.a.h;

public final class w
implements b.a {
    public final /* synthetic */ h a;

    public w(h h2) {
        this.a = h2;
    }

    public final void a(b b2) {
        this.a.g((Object)b2);
    }
}

