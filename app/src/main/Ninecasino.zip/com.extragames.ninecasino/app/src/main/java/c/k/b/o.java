/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.view.View
 *  c.h.f.a
 *  c.h.f.a$a
 *  c.k.b.m
 *  java.lang.Object
 */
package c.k.b;

import android.animation.Animator;
import android.view.View;
import c.h.f.a;
import c.k.b.m;

public class o
implements a.a {
    public final /* synthetic */ m a;

    public o(m m2) {
        this.a = m2;
    }

    public void a() {
        if (this.a.i() != null) {
            View view = this.a.i();
            this.a.m0(null);
            view.clearAnimation();
        }
        this.a.n0(null);
    }
}

