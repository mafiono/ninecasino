/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.Cursor
 *  java.lang.Object
 */
package d.c.a.b.j.t.i;

import android.database.Cursor;
import d.c.a.b.j.t.i.t;

public final class q
implements t.b {
    public static final q a = new q();

    public Object a(Object object) {
        return ((Cursor)object).moveToNext();
    }
}

