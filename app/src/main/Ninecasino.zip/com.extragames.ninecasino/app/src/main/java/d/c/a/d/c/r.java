/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 */
package d.c.a.d.c;

public final class r
extends Exception {
    public r(int n2, String string) {
        super(string);
    }
}

