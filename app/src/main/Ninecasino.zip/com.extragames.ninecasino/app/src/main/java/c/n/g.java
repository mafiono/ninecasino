/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.n.f
 *  c.n.g$a
 *  c.n.g$b
 *  d.c.a.e.a
 *  f.k
 *  f.m.d
 *  f.o.a.p
 *  f.o.b.i
 *  g.a.z0
 *  java.lang.Object
 *  java.lang.String
 */
package c.n;

import c.n.f;
import c.n.g;
import f.k;
import f.m.d;
import f.o.a.p;
import f.o.b.i;
import g.a.z;
import g.a.z0;

public abstract class g
implements z {
    public abstract f i();

    public final z0 j(p<? super z, ? super d<? super k>, ? extends Object> p2) {
        i.e(p2, (String)"block");
        return d.c.a.e.a.W((z)this, null, null, (p)new a(this, p2, null), (int)3, null);
    }

    public final z0 k(p<? super z, ? super d<? super k>, ? extends Object> p2) {
        i.e(p2, (String)"block");
        return d.c.a.e.a.W((z)this, null, null, (p)new b(this, p2, null), (int)3, null);
    }
}

