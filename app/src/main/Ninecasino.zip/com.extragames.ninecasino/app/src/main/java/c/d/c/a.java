/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.d.c.g
 *  c.d.c.g$a
 */
package c.d.c;

import c.d.c.a;
import c.d.c.c;
import c.d.c.g;

public class a
extends c {
    public void n() {
        g.r = new g.a(this){

            public void a(android.graphics.Canvas canvas, android.graphics.RectF rectF, float f2, android.graphics.Paint paint) {
                canvas.drawRoundRect(rectF, f2, f2, paint);
            }
        };
    }
}

