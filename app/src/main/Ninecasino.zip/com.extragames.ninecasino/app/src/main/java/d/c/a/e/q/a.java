/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.material.floatingactionbutton.FloatingActionButton
 *  com.google.android.material.floatingactionbutton.FloatingActionButton$a
 *  java.lang.Object
 */
package d.c.a.e.q;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import d.c.a.e.q.d;

public class a
implements d.f {
    public final /* synthetic */ FloatingActionButton.a a;
    public final /* synthetic */ FloatingActionButton b;

    public a(FloatingActionButton floatingActionButton, FloatingActionButton.a a2) {
        this.b = floatingActionButton;
        this.a = a2;
    }
}

