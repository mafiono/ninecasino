/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.f.b.i.d
 */
package c.f.b.i;

import c.f.b.i.d;
import c.f.b.i.e;
import c.f.b.i.h;

public class j
extends h {
    @Override
    public void a(e e2) {
        for (int i2 = 0; i2 < this.f0; ++i2) {
            this.e0[i2];
        }
    }
}

