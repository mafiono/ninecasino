/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package d.c.a.b.j.v;

import d.c.a.b.j.v.e;

public final class b
implements Object<a> {
    public Object get() {
        return new e();
    }

}

