/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.h.c.b.b
 *  c.h.c.b.d
 *  java.lang.Object
 */
package c.h.c.b;

import c.h.c.b.b;
import c.h.c.b.d;

public final class c
implements b {
    public final d[] a;

    public c(d[] arrd) {
        this.a = arrd;
    }
}

