/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.b.j.s.a
 *  java.lang.Object
 */
package d.c.a.b.i;

import d.c.a.b.j.s.a;

public final class c
implements a {
    public static final c a = new c();
}

