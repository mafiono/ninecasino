/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.d.g.f.l8
 *  d.c.a.d.g.f.o8
 *  d.c.a.d.h.b.j3
 *  java.lang.Object
 */
package d.c.a.d.h.b;

import d.c.a.d.g.f.l8;
import d.c.a.d.g.f.o8;
import d.c.a.d.h.b.j3;

public final class s2
implements j3 {
    public static final j3 a = new s2();

    public final Object a() {
        return ((o8)l8.f.a()).a();
    }
}

