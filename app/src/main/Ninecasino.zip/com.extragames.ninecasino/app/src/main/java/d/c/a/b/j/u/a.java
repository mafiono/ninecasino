/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 */
package d.c.a.b.j.u;

public class a
extends RuntimeException {
    public a(String string, Throwable throwable) {
        super(string, throwable);
    }
}

