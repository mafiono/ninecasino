/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package d.c.a.e.r;

import d.c.a.e.r.c;
import d.c.a.e.t.a;

public class b
implements a.a {
    public final /* synthetic */ c a;

    public b(c c3) {
        this.a = c3;
    }
}

