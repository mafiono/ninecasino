/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Cloneable
 */
package d.c.a.e.f;

public class f
extends d.c.a.e.w.f
implements Cloneable {
    public float e;
    public float f;
    public float g;
    public float h;
}

