/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.appcompat.widget.ContentFrameLayout
 *  androidx.appcompat.widget.ContentFrameLayout$a
 *  java.lang.Object
 */
package c.b.c;

import androidx.appcompat.widget.ContentFrameLayout;
import c.b.c.k;

public class n
implements ContentFrameLayout.a {
    public final /* synthetic */ k a;

    public n(k k2) {
        this.a = k2;
    }
}

