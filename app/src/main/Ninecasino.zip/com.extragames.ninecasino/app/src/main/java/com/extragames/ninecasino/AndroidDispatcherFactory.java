package com.extragames.ninecasino;

public class AndroidDispatcherFactory extends MainDispatcherFactory {
}
