/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  androidx.appcompat.app.AlertController
 *  androidx.core.widget.NestedScrollView
 *  androidx.core.widget.NestedScrollView$b
 *  java.lang.Object
 */
package c.b.c;

import android.view.View;
import androidx.appcompat.app.AlertController;
import androidx.core.widget.NestedScrollView;

public class b
implements NestedScrollView.b {
    public final /* synthetic */ View a;
    public final /* synthetic */ View b;

    public b(AlertController alertController, View view, View view2) {
        this.a = view;
        this.b = view2;
    }
}

