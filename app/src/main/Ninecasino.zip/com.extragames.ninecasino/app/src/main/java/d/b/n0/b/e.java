/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  d.b.n0.b.e$a
 *  d.b.n0.b.h
 *  d.b.n0.b.h$a
 */
package d.b.n0.b;

import android.os.Parcel;
import android.os.Parcelable;
import d.b.n0.b.e;
import d.b.n0.b.h;

public final class e
extends h<e, b> {
    public static final Parcelable.Creator<e> CREATOR = new a();

    public e(Parcel parcel) {
        super(parcel);
    }

    public e(b b2, a a2) {
        super((h.a)b2);
    }

    public static final class b
    extends h.a<e, b> {
    }

}

