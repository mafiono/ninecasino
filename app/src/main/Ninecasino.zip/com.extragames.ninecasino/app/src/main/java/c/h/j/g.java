/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  c.h.j.i
 *  java.lang.Object
 */
package c.h.j;

import android.view.View;
import c.h.j.i;

public interface g
extends i {
    void d(View var1, View var2, int var3, int var4);

    void i(View var1, int var2);

    void j(View var1, int var2, int var3, int[] var4, int var5);

    void n(View var1, int var2, int var3, int var4, int var5, int var6);

    boolean o(View var1, View var2, int var3, int var4);
}

