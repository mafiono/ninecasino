/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package d.c.a.d.c;

import d.c.a.d.c.h;

public final class o
implements Runnable {
    public final h e;

    public o(h h2) {
        this.e = h2;
    }

    public final void run() {
        this.e.a(2, "Service disconnected");
    }
}

