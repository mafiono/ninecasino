/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.database.ContentObserver
 *  android.os.Bundle
 *  android.os.SystemClock
 *  android.text.TextUtils
 *  d.c.a.d.d.l.c.c
 *  d.c.a.d.d.m.m
 *  d.c.a.d.d.p.c
 *  d.c.a.d.d.p.d
 *  d.c.a.d.d.q.c
 *  d.c.a.d.g.f.c2
 *  d.c.a.d.g.f.f
 *  d.c.a.d.g.f.k2
 *  d.c.a.d.g.f.l2
 *  d.c.a.d.g.f.s2
 *  d.c.a.d.g.f.t2
 *  d.c.a.d.g.f.v1
 *  d.c.a.d.g.f.w8
 *  d.c.a.d.g.f.y1
 *  d.c.a.d.g.f.z2
 *  d.c.a.d.h.b.a
 *  d.c.a.d.h.b.a6
 *  d.c.a.d.h.b.a7
 *  d.c.a.d.h.b.c
 *  d.c.a.d.h.b.c5
 *  d.c.a.d.h.b.e6
 *  d.c.a.d.h.b.f4
 *  d.c.a.d.h.b.f6
 *  d.c.a.d.h.b.f7
 *  d.c.a.d.h.b.j
 *  d.c.a.d.h.b.j7
 *  d.c.a.d.h.b.ka
 *  d.c.a.d.h.b.l3
 *  d.c.a.d.h.b.o3
 *  d.c.a.d.h.b.o4
 *  d.c.a.d.h.b.p3
 *  d.c.a.d.h.b.p4
 *  d.c.a.d.h.b.q3
 *  d.c.a.d.h.b.r
 *  d.c.a.d.h.b.s3
 *  d.c.a.d.h.b.s7
 *  d.c.a.d.h.b.t4
 *  d.c.a.d.h.b.t5
 *  d.c.a.d.h.b.u3
 *  d.c.a.d.h.b.v5
 *  d.c.a.d.h.b.w9
 *  d.c.a.d.h.b.y4
 *  d.c.a.d.h.b.y8
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.Objects
 *  java.util.concurrent.atomic.AtomicInteger
 */
package d.c.a.d.h.b;

import android.app.Application;
import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import d.c.a.d.d.m.m;
import d.c.a.d.d.p.d;
import d.c.a.d.g.f.c2;
import d.c.a.d.g.f.f;
import d.c.a.d.g.f.k2;
import d.c.a.d.g.f.l2;
import d.c.a.d.g.f.s2;
import d.c.a.d.g.f.t2;
import d.c.a.d.g.f.v1;
import d.c.a.d.g.f.w8;
import d.c.a.d.g.f.y1;
import d.c.a.d.g.f.z2;
import d.c.a.d.h.b.a;
import d.c.a.d.h.b.a6;
import d.c.a.d.h.b.a7;
import d.c.a.d.h.b.c;
import d.c.a.d.h.b.c5;
import d.c.a.d.h.b.e6;
import d.c.a.d.h.b.f4;
import d.c.a.d.h.b.f6;
import d.c.a.d.h.b.f7;
import d.c.a.d.h.b.j;
import d.c.a.d.h.b.j7;
import d.c.a.d.h.b.ka;
import d.c.a.d.h.b.l3;
import d.c.a.d.h.b.o3;
import d.c.a.d.h.b.o4;
import d.c.a.d.h.b.p3;
import d.c.a.d.h.b.p4;
import d.c.a.d.h.b.q3;
import d.c.a.d.h.b.r;
import d.c.a.d.h.b.s3;
import d.c.a.d.h.b.s7;
import d.c.a.d.h.b.t4;
import d.c.a.d.h.b.t5;
import d.c.a.d.h.b.u3;
import d.c.a.d.h.b.u5;
import d.c.a.d.h.b.v5;
import d.c.a.d.h.b.w9;
import d.c.a.d.h.b.y4;
import d.c.a.d.h.b.y8;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class w4
implements v5 {
    public static volatile w4 H;
    public volatile Boolean A;
    public Boolean B;
    public Boolean C;
    public volatile boolean D;
    public int E;
    public AtomicInteger F;
    public final long G;
    public final Context a;
    public final String b;
    public final String c;
    public final String d;
    public final boolean e;
    public final ka f;
    public final c g;
    public final f4 h;
    public final s3 i;
    public final t4 j;
    public final y8 k;
    public final w9 l;
    public final q3 m;
    public final d.c.a.d.d.p.c n;
    public final j7 o;
    public final e6 p;
    public final a q;
    public final f7 r;
    public o3 s;
    public s7 t;
    public j u;
    public p3 v;
    public o4 w;
    public boolean x;
    public Boolean y;
    public long z;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public w4(a6 a62) {
        t4 t42;
        block17 : {
            String string;
            u3 u32;
            block18 : {
                block16 : {
                    Object object;
                    Bundle bundle;
                    ka ka2;
                    this.x = false;
                    this.F = new AtomicInteger(0);
                    Context context = a62.a;
                    this.f = ka2 = new ka();
                    d.c.a.d.b.a.e = ka2;
                    this.a = context;
                    this.b = a62.b;
                    this.c = a62.c;
                    this.d = a62.d;
                    this.e = a62.h;
                    this.A = a62.e;
                    this.D = true;
                    f f2 = a62.g;
                    if (f2 != null && (bundle = f2.k) != null) {
                        Object object2;
                        Object object3 = bundle.get("measurementEnabled");
                        if (object3 instanceof Boolean) {
                            this.B = (Boolean)object3;
                        }
                        if ((object2 = f2.k.get("measurementDeactivated")) instanceof Boolean) {
                            this.C = (Boolean)object2;
                        }
                    }
                    Object object4 = object = l2.g;
                    // MONITORENTER : object4
                    t2 t22 = l2.h;
                    Context context2 = context.getApplicationContext();
                    if (context2 == null) {
                        context2 = context;
                    }
                    if (t22 == null || t22.a() != context2) {
                        Context context3;
                        y1.c();
                        s2.b();
                        Class<c2> class_ = c2.class;
                        // MONITORENTER : d.c.a.d.g.f.c2.class
                        c2 c22 = c2.c;
                        if (c22 != null && (context3 = c22.a) != null && c22.b != null) {
                            context3.getContentResolver().unregisterContentObserver(c2.c.b);
                        }
                        c2.c = null;
                        // MONITOREXIT : class_
                        l2.h = new v1(context2, m.l((z2)new k2(context2)));
                        l2.j.incrementAndGet();
                    }
                    // MONITOREXIT : object4
                    this.n = d.a;
                    Long l3 = a62.i;
                    long l4 = l3 != null ? l3 : System.currentTimeMillis();
                    this.G = l4;
                    this.g = new c(this);
                    f4 f42 = new f4(this);
                    f42.p();
                    this.h = f42;
                    s3 s32 = new s3(this);
                    s32.p();
                    this.i = s32;
                    w9 w92 = new w9(this);
                    w92.p();
                    this.l = w92;
                    q3 q32 = new q3(this);
                    q32.p();
                    this.m = q32;
                    this.q = new a(this);
                    j7 j72 = new j7(this);
                    j72.u();
                    this.o = j72;
                    e6 e62 = new e6(this);
                    e62.u();
                    this.p = e62;
                    y8 y82 = new y8(this);
                    y82.u();
                    this.k = y82;
                    f7 f72 = new f7(this);
                    f72.p();
                    this.r = f72;
                    t42 = new t4(this);
                    t42.p();
                    this.j = t42;
                    f f3 = a62.g;
                    boolean bl = false;
                    if (f3 != null) {
                        long l5 = f3.f LCMP 0L;
                        bl = l5 != false;
                    }
                    boolean bl2 = bl ^ true;
                    if (!(context.getApplicationContext() instanceof Application)) break block16;
                    e6 e63 = this.s();
                    if (!(e63.a.a.getApplicationContext() instanceof Application)) break block17;
                    Application application = (Application)e63.a.a.getApplicationContext();
                    if (e63.c == null) {
                        e63.c = new a7(e63, null);
                    }
                    if (!bl2) break block17;
                    application.unregisterActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)e63.c);
                    application.registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)e63.c);
                    u32 = e63.i().n;
                    string = "Registered activity lifecycle callback";
                    break block18;
                }
                u32 = this.i().i;
                string = "Application context is not an Application";
            }
            u32.a(string);
        }
        t42.v((Runnable)new y4(this, a62));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static w4 b(Context context, f f2, Long l3) {
        if (f2 != null && (f2.i == null || f2.j == null)) {
            f f3;
            f2 = f3 = new f(f2.e, f2.f, f2.g, f2.h, null, null, f2.k);
        }
        Objects.requireNonNull((Object)context, "null reference");
        Objects.requireNonNull((Object)context.getApplicationContext(), "null reference");
        if (H == null) {
            Class<w4> class_ = w4.class;
            synchronized (w4.class) {
                if (H != null) return H;
                H = new w4(new a6(context, f2, l3));
                // ** MonitorExit[var8_4] (shouldn't be in output)
                return H;
            }
        }
        if (f2 == null) return H;
        Bundle bundle = f2.k;
        if (bundle == null) return H;
        if (!bundle.containsKey("dataCollectionDefaultEnabled")) return H;
        w4.H.A = f2.k.getBoolean("dataCollectionDefaultEnabled");
        return H;
    }

    public static void c(u5 u52) {
        if (u52 != null) {
            return;
        }
        throw new IllegalStateException("Component not created");
    }

    public static void p(c5 c52) {
        if (c52 != null) {
            if (c52.b) {
                return;
            }
            String string = String.valueOf((Object)c52.getClass());
            StringBuilder stringBuilder = new StringBuilder(27 + string.length());
            stringBuilder.append("Component not initialized: ");
            stringBuilder.append(string);
            throw new IllegalStateException(stringBuilder.toString());
        }
        throw new IllegalStateException("Component not created");
    }

    public static void q(t5 t52) {
        if (t52 != null) {
            if (t52.n()) {
                return;
            }
            String string = String.valueOf((Object)t52.getClass());
            StringBuilder stringBuilder = new StringBuilder(27 + string.length());
            stringBuilder.append("Component not initialized: ");
            stringBuilder.append(string);
            throw new IllegalStateException(stringBuilder.toString());
        }
        throw new IllegalStateException("Component not created");
    }

    public final a A() {
        a a2 = this.q;
        if (a2 != null) {
            return a2;
        }
        throw new IllegalStateException("Component not created");
    }

    public final boolean B() {
        return this.A != null && this.A != false;
    }

    public final c a() {
        return this.g;
    }

    public final boolean d() {
        return this.e() == 0;
    }

    public final int e() {
        this.f().b();
        if (this.g.w()) {
            return 1;
        }
        Boolean bl = this.C;
        if (bl != null && bl.booleanValue()) {
            return 2;
        }
        if (w8.b() && this.g.o(r.H0) && !this.h()) {
            return 8;
        }
        Boolean bl2 = this.o().x();
        if (bl2 != null) {
            if (bl2.booleanValue()) {
                return 0;
            }
            return 3;
        }
        Boolean bl3 = this.g.v("firebase_analytics_collection_enabled");
        if (bl3 != null) {
            if (bl3.booleanValue()) {
                return 0;
            }
            return 4;
        }
        Boolean bl4 = this.B;
        if (bl4 != null) {
            if (bl4.booleanValue()) {
                return 0;
            }
            return 5;
        }
        if (d.c.a.d.d.l.c.c.a((String)"isMeasurementExplicitlyDisabled").c) {
            return 6;
        }
        if (this.g.o(r.S) && this.A != null) {
            if (this.A.booleanValue()) {
                return 0;
            }
            return 7;
        }
        return 0;
    }

    public final t4 f() {
        w4.q((t5)this.j);
        return this.j;
    }

    public final d.c.a.d.d.p.c g() {
        return this.n;
    }

    public final boolean h() {
        this.f().b();
        return this.D;
    }

    public final s3 i() {
        w4.q((t5)this.i);
        return this.i;
    }

    public final Context j() {
        return this.a;
    }

    public final ka k() {
        return this.f;
    }

    public final void l() {
        throw new IllegalStateException("Unexpected call on client side");
    }

    public final boolean m() {
        block2 : {
            block4 : {
                boolean bl;
                block6 : {
                    block5 : {
                        Boolean bl2;
                        block3 : {
                            if (!this.x) break block2;
                            this.f().b();
                            Boolean bl3 = this.y;
                            if (bl3 == null || this.z == 0L) break block3;
                            if (bl3.booleanValue()) break block4;
                            Objects.requireNonNull((d)this.n);
                            if (Math.abs(SystemClock.elapsedRealtime() - this.z) <= 1000L) break block4;
                        }
                        Objects.requireNonNull((d)this.n);
                        this.z = SystemClock.elapsedRealtime();
                        boolean bl4 = this.t().p0("android.permission.INTERNET") && this.t().p0("android.permission.ACCESS_NETWORK_STATE") && (d.c.a.d.d.q.c.a((Context)this.a).c() || this.g.B() || p4.a((Context)this.a) && w9.U((Context)this.a));
                        this.y = bl2 = Boolean.valueOf(bl4);
                        if (!bl2.booleanValue()) break block4;
                        w9 w92 = this.t();
                        p3 p32 = this.z();
                        p32.t();
                        String string = p32.k;
                        p3 p33 = this.z();
                        p33.t();
                        String string2 = p33.l;
                        p3 p34 = this.z();
                        p34.t();
                        if (w92.c0(string, string2, p34.m)) break block5;
                        p3 p35 = this.z();
                        p35.t();
                        boolean bl5 = TextUtils.isEmpty((CharSequence)p35.l);
                        bl = false;
                        if (bl5) break block6;
                    }
                    bl = true;
                }
                this.y = bl;
            }
            return this.y;
        }
        throw new IllegalStateException("AppMeasurement is not initialized");
    }

    public final f7 n() {
        w4.q((t5)this.r);
        return this.r;
    }

    public final f4 o() {
        w4.c((u5)this.h);
        return this.h;
    }

    public final y8 r() {
        w4.p((c5)this.k);
        return this.k;
    }

    public final e6 s() {
        w4.p((c5)this.p);
        return this.p;
    }

    public final w9 t() {
        w4.c((u5)this.l);
        return this.l;
    }

    public final q3 u() {
        w4.c((u5)this.m);
        return this.m;
    }

    public final boolean v() {
        return TextUtils.isEmpty(this.b);
    }

    public final j7 w() {
        w4.p((c5)this.o);
        return this.o;
    }

    public final s7 x() {
        w4.p((c5)this.t);
        return this.t;
    }

    public final j y() {
        w4.q((t5)this.u);
        return this.u;
    }

    public final p3 z() {
        w4.p((c5)this.v);
        return this.v;
    }
}

