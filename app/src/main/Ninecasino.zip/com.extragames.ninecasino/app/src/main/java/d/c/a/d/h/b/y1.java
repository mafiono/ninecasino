/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.d.g.f.rb
 *  d.c.a.d.g.f.ub
 *  d.c.a.d.h.b.j3
 *  java.lang.Object
 */
package d.c.a.d.h.b;

import d.c.a.d.g.f.rb;
import d.c.a.d.g.f.ub;
import d.c.a.d.h.b.j3;

public final class y1
implements j3 {
    public static final j3 a = new y1();

    public final Object a() {
        return ((ub)rb.f.a()).b();
    }
}

