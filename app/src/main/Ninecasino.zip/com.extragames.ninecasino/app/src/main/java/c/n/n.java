/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.n.k
 *  java.lang.Deprecated
 *  java.lang.Object
 */
package c.n;

import c.n.k;
import c.n.m;

@Deprecated
public interface n
extends k {
    m a();
}

