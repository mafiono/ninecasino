/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  c.h.d.b
 *  c.h.j.k
 *  c.h.j.w
 *  c.h.j.w$h
 *  com.google.android.material.bottomsheet.BottomSheetBehavior
 *  java.lang.Object
 */
package d.c.a.e.r;

import android.view.View;
import c.h.d.b;
import c.h.j.w;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import d.c.a.e.r.m;
import d.c.a.e.r.n;

public final class k
implements c.h.j.k {
    public final /* synthetic */ m a;
    public final /* synthetic */ n b;

    public k(m m2, n n2) {
        this.a = m2;
        this.b = n2;
    }

    public w a(View view, w w3) {
        m m2 = this.a;
        d.c.a.e.g.b b3 = (d.c.a.e.g.b)m2;
        b3.a.j = w3.a.e().d;
        b3.a.S(false);
        return w3;
    }
}

