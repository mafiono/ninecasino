/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  c.h.j.n
 *  c.h.j.n$b
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 */
package c.h.j;

import android.view.View;
import c.h.j.n;

public class p
extends n.b<CharSequence> {
    public p(int n2, Class class_, int n3, int n4) {
        super(n2, class_, n3, n4);
    }

    public Object b(View view) {
        return view.getAccessibilityPaneTitle();
    }
}

