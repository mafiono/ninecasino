/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.b.g
 *  java.lang.String
 */
package d.b;

import d.b.g;

public class i
extends g {
    public static final long serialVersionUID = 1L;

    public i() {
    }

    public i(String string) {
        super(string);
    }
}

