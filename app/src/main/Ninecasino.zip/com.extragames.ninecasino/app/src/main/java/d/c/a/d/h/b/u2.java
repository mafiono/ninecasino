/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.d.g.f.n9
 *  d.c.a.d.g.f.o9
 *  d.c.a.d.h.b.j3
 *  java.lang.Object
 */
package d.c.a.d.h.b;

import d.c.a.d.g.f.n9;
import d.c.a.d.g.f.o9;
import d.c.a.d.h.b.j3;

public final class u2
implements j3 {
    public static final j3 a = new u2();

    public final Object a() {
        return ((n9)o9.f.a()).b();
    }
}

