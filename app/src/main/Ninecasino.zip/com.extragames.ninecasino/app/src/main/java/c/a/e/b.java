/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  java.lang.Object
 */
package c.a.e;

import android.annotation.SuppressLint;

public interface b<O> {
    void a(@SuppressLint(value={"UnknownNullness"}) O var1);
}

