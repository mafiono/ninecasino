/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.d.g.f.na
 *  d.c.a.d.g.f.qa
 *  d.c.a.d.h.b.j3
 *  java.lang.Object
 */
package d.c.a.d.h.b;

import d.c.a.d.g.f.na;
import d.c.a.d.g.f.qa;
import d.c.a.d.h.b.j3;

public final class v1
implements j3 {
    public static final j3 a = new v1();

    public final Object a() {
        return ((qa)na.f.a()).b();
    }
}

