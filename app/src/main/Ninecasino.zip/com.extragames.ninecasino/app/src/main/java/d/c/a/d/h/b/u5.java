/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  d.c.a.d.d.p.c
 *  d.c.a.d.h.b.f4
 *  d.c.a.d.h.b.j
 *  d.c.a.d.h.b.ka
 *  d.c.a.d.h.b.q3
 *  d.c.a.d.h.b.s3
 *  d.c.a.d.h.b.t4
 *  d.c.a.d.h.b.v5
 *  d.c.a.d.h.b.w9
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 */
package d.c.a.d.h.b;

import android.content.Context;
import d.c.a.d.d.p.c;
import d.c.a.d.h.b.f4;
import d.c.a.d.h.b.j;
import d.c.a.d.h.b.ka;
import d.c.a.d.h.b.q3;
import d.c.a.d.h.b.s3;
import d.c.a.d.h.b.t4;
import d.c.a.d.h.b.v5;
import d.c.a.d.h.b.w4;
import d.c.a.d.h.b.w9;
import java.util.Objects;

public class u5
implements v5 {
    public final w4 a;

    public u5(w4 w42) {
        Objects.requireNonNull((Object)w42, "null reference");
        this.a = w42;
    }

    public void a() {
        this.a.f().a();
    }

    public void b() {
        this.a.f().b();
    }

    public j c() {
        return this.a.y();
    }

    public q3 d() {
        return this.a.u();
    }

    public w9 e() {
        return this.a.t();
    }

    public t4 f() {
        return this.a.f();
    }

    public c g() {
        return this.a.n;
    }

    public s3 i() {
        return this.a.i();
    }

    public Context j() {
        return this.a.a;
    }

    public ka k() {
        return this.a.f;
    }

    public f4 l() {
        return this.a.o();
    }
}

