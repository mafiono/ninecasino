/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.b.h
 *  java.lang.Exception
 *  java.lang.Object
 */
package d.c.a.b.j;

import d.c.a.b.h;

public final class k
implements h {
    public static final k a = new k();

    public void a(Exception exception) {
    }
}

