/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.f.b.i.d
 *  c.f.b.i.e
 *  c.f.b.i.g
 */
package c.f.b.i;

import c.f.b.i.d;
import c.f.b.i.e;
import c.f.b.i.g;

public class h
extends d
implements g {
    public d[] e0 = new d[4];
    public int f0 = 0;

    public void a(e e2) {
    }
}

