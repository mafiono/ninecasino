/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  c.h.f.a
 *  c.h.f.a$a
 *  java.lang.Object
 */
package c.k.b;

import android.animation.Animator;
import c.h.f.a;
import c.k.b.c;

public class e
implements a.a {
    public final /* synthetic */ Animator a;

    public e(c c2, Animator animator) {
        this.a = animator;
    }

    public void a() {
        this.a.cancel();
    }
}

