/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.h.c.b.d
 *  c.h.d.j
 *  c.h.d.j$b
 *  java.lang.Object
 */
package c.h.d;

import c.h.c.b.d;
import c.h.d.j;

public class k
implements j.b<d> {
    public k(j j2) {
    }

    public int a(Object object) {
        return ((d)object).b;
    }

    public boolean b(Object object) {
        return ((d)object).c;
    }
}

