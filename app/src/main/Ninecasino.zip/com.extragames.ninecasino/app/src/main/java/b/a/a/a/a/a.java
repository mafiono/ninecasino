/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IInterface
 *  java.lang.Object
 */
package b.a.a.a.a;

import android.os.IInterface;

public interface a
extends IInterface {
}

