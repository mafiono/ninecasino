/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.h.c.b.b
 *  c.h.g.a
 *  java.lang.Object
 */
package c.h.c.b;

import c.h.c.b.b;
import c.h.g.a;

public final class e
implements b {
    public final a a;
    public final int b;
    public final int c;

    public e(a a2, int n2, int n3) {
        this.a = a2;
        this.c = n2;
        this.b = n3;
    }
}

