/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Typeface
 *  java.lang.Object
 */
package d.c.a.e.t;

import android.graphics.Typeface;

public abstract class d {
    public abstract void a(int var1);

    public abstract void b(Typeface var1, boolean var2);
}

