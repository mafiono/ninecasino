/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.d.g.f.la
 *  d.c.a.d.g.f.ma
 *  d.c.a.d.h.b.j3
 *  java.lang.Object
 */
package d.c.a.d.h.b;

import d.c.a.d.g.f.la;
import d.c.a.d.g.f.ma;
import d.c.a.d.h.b.j3;

public final class s1
implements j3 {
    public static final j3 a = new s1();

    public final Object a() {
        return ((la)ma.f.a()).c();
    }
}

