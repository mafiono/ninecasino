/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IInterface
 *  java.lang.Object
 */
package d.c.a.d.c;

import android.os.IInterface;

public interface b
extends IInterface {
}

