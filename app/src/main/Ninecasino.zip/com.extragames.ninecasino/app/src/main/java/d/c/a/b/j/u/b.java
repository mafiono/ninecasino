/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package d.c.a.b.j.u;

public interface b {
    <T> T a(a<T> var1);

    interface a<T> {
        T execute();
    }

}

