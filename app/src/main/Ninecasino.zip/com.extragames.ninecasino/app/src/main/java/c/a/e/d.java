/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.a.e.c
 *  c.a.e.e
 *  c.a.e.h.a
 *  c.h.b.d
 *  java.lang.Object
 *  java.lang.String
 */
package c.a.e;

import c.a.e.c;
import c.a.e.e;
import c.a.e.h.a;

public class d
extends c<I> {
    public final /* synthetic */ int a;
    public final /* synthetic */ a b;
    public final /* synthetic */ String c;
    public final /* synthetic */ e d;

    public d(e e2, int n2, a a2, String string) {
        this.d = e2;
        this.a = n2;
        this.b = a2;
        this.c = string;
    }

    public void a(I i2, c.h.b.d d2) {
        this.d.b(this.a, this.b, i2, null);
    }

    public void b() {
        this.d.e(this.c);
    }
}

