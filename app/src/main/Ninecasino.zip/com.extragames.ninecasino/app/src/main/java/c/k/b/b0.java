/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.k.b.a0
 */
package c.k.b;

import c.k.b.a0;

public class b0
extends a0 {
}

