/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.b.j.f
 *  d.c.a.b.j.i
 *  d.c.a.b.j.t.h.s
 *  d.c.a.b.j.t.i.c
 *  d.c.a.b.j.t.i.h
 *  java.lang.Object
 */
package d.c.a.b.j.t;

import d.c.a.b.j.f;
import d.c.a.b.j.i;
import d.c.a.b.j.t.h.s;
import d.c.a.b.j.t.i.c;
import d.c.a.b.j.t.i.h;
import d.c.a.b.j.u.b;

public final class b
implements b.a {
    public final d.c.a.b.j.t.c a;
    public final i b;
    public final f c;

    public b(d.c.a.b.j.t.c c2, i i2, f f2) {
        this.a = c2;
        this.b = i2;
        this.c = f2;
    }

    public Object execute() {
        d.c.a.b.j.t.c c2 = this.a;
        i i2 = this.b;
        f f2 = this.c;
        c2.d.e0(i2, f2);
        c2.a.a(i2, 1);
        return null;
    }
}

