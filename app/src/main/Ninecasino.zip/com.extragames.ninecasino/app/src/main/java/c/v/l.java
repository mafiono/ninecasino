/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package c.v;

import c.v.i;

public class l
implements i.d {
    @Override
    public void a(i i2) {
    }

    @Override
    public void b(i i2) {
    }

    @Override
    public void c(i i2) {
    }

    @Override
    public void d(i i2) {
    }
}

