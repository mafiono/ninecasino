/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  d.b.j0.s
 *  java.lang.String
 */
package d.b.k0;

import android.content.Context;
import d.b.j0.s;

public final class j
extends s {
    public j(Context context, String string) {
        super(context, 65536, 65537, 20121101, string);
    }
}

