/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.b.j.t.i.c
 *  java.lang.Object
 */
package d.c.a.b.j.t.h;

import d.c.a.b.j.t.i.c;
import d.c.a.b.j.u.b;

public final class k
implements b.a {
    public final c a;

    public k(c c2) {
        this.a = c2;
    }

    public Object execute() {
        return this.a.f();
    }
}

