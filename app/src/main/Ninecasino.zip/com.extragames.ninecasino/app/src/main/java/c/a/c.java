/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.activity.OnBackPressedDispatcher
 *  c.n.k
 *  java.lang.Object
 */
package c.a;

import androidx.activity.OnBackPressedDispatcher;
import c.n.k;

public interface c
extends k {
    OnBackPressedDispatcher c();
}

