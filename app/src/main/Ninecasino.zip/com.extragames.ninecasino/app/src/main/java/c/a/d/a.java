/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  java.util.Set
 *  java.util.concurrent.CopyOnWriteArraySet
 */
package c.a.d;

import android.content.Context;
import c.a.d.b;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

public final class a {
    public final Set<b> a = new CopyOnWriteArraySet();
    public volatile Context b;
}

