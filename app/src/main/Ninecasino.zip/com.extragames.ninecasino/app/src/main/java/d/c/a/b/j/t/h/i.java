/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.b.j.i
 *  d.c.a.b.j.t.h.m
 *  d.c.a.b.j.t.i.c
 *  java.lang.Iterable
 *  java.lang.Object
 */
package d.c.a.b.j.t.h;

import d.c.a.b.j.t.h.m;
import d.c.a.b.j.t.i.c;
import d.c.a.b.j.u.b;

public final class i
implements b.a {
    public final m a;
    public final d.c.a.b.j.i b;

    public i(m m2, d.c.a.b.j.i i2) {
        this.a = m2;
        this.b = i2;
    }

    public Object execute() {
        m m2 = this.a;
        d.c.a.b.j.i i2 = this.b;
        return m2.c.C(i2);
    }
}

