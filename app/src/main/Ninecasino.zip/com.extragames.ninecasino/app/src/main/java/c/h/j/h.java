/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  java.lang.Object
 */
package c.h.j;

import android.view.View;
import c.h.j.g;

public interface h
extends g {
    void m(View var1, int var2, int var3, int var4, int var5, int var6, int[] var7);
}

