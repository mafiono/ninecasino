/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 */
package d.c.a.b.j.t.i;

public final class f
implements Object<Integer> {
    public Object get() {
        return 4;
    }
}

