/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.b.i.e.a
 *  d.c.a.b.i.e.b$a
 *  d.c.a.b.i.e.b$b
 *  d.c.a.b.i.e.b$c
 *  d.c.a.b.i.e.b$d
 *  d.c.a.b.i.e.b$e
 *  d.c.a.b.i.e.b$f
 *  d.c.a.b.i.e.j
 *  d.c.a.b.i.e.k
 *  d.c.a.b.i.e.l
 *  d.c.a.b.i.e.m
 *  d.c.a.b.i.e.o
 *  d.c.b.o.i.e
 *  java.lang.Object
 *  java.util.Map
 */
package d.c.a.b.i.e;

import d.c.a.b.i.e.b;
import d.c.a.b.i.e.g;
import d.c.a.b.i.e.i;
import d.c.a.b.i.e.j;
import d.c.a.b.i.e.k;
import d.c.a.b.i.e.l;
import d.c.a.b.i.e.m;
import d.c.a.b.i.e.o;
import java.util.Map;

public final class b
implements d.c.b.o.h.a {
    public static final d.c.b.o.h.a a = new b();

    public void a(d.c.b.o.h.b<?> b2) {
        b b3 = b.a;
        d.c.b.o.i.e e2 = (d.c.b.o.i.e)b2;
        e2.a.put(j.class, (Object)b3);
        e2.b.remove(j.class);
        e2.a.put(d.class, (Object)b3);
        e2.b.remove(d.class);
        e e3 = e.a;
        e2.a.put(m.class, (Object)e3);
        e2.b.remove(m.class);
        e2.a.put(g.class, (Object)e3);
        e2.b.remove(g.class);
        c c2 = c.a;
        e2.a.put(k.class, (Object)c2);
        e2.b.remove(k.class);
        e2.a.put(e.class, (Object)c2);
        e2.b.remove(e.class);
        a a2 = a.a;
        e2.a.put(d.c.a.b.i.e.a.class, (Object)a2);
        e2.b.remove(d.c.a.b.i.e.a.class);
        e2.a.put(c.class, (Object)a2);
        e2.b.remove(c.class);
        d d2 = d.a;
        e2.a.put(l.class, (Object)d2);
        e2.b.remove(l.class);
        e2.a.put(f.class, (Object)d2);
        e2.b.remove(f.class);
        f f2 = f.a;
        e2.a.put(o.class, (Object)f2);
        e2.b.remove(o.class);
        e2.a.put(i.class, (Object)f2);
        e2.b.remove(i.class);
    }
}

