package com.extragames.ninecasino;

import android.app.Application;

public class App extends Application {
}
