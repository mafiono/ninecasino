/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  c.h.f.a
 *  c.h.f.a$a
 *  java.lang.Object
 */
package c.k.b;

import android.view.View;
import c.h.f.a;
import c.k.b.c;

public class g
implements a.a {
    public final /* synthetic */ View a;

    public g(c c2, View view) {
        this.a = view;
    }

    public void a() {
        this.a.clearAnimation();
    }
}

