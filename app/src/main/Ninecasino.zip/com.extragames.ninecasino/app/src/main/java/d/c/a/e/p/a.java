/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package d.c.a.e.p;

public interface a {
    boolean a();
}

