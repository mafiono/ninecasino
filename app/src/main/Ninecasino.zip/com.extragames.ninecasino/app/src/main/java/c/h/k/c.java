/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.ListView
 *  c.h.k.a
 */
package c.h.k;

import android.view.View;
import android.widget.ListView;
import c.h.k.a;

public class c
extends a {
    public final ListView v;

    public c(ListView listView) {
        super((View)listView);
        this.v = listView;
    }
}

