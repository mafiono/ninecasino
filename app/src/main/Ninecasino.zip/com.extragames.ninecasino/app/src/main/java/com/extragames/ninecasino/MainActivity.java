package com.extragames.ninecasino;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int Game_Activity = 0;
        setContentView(Game_Activity);
    }

    private static class Game_Activity {
    }
}