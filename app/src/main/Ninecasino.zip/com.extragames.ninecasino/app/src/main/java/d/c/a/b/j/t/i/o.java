/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.sqlite.SQLiteDatabase
 *  java.lang.Object
 */
package d.c.a.b.j.t.i;

import android.database.sqlite.SQLiteDatabase;
import d.c.a.b.j.t.i.t;
import d.c.a.b.j.t.i.z;

public final class o
implements t.d {
    public final z a;

    public o(z z2) {
        this.a = z2;
    }

    public Object a() {
        return this.a.getWritableDatabase();
    }
}

