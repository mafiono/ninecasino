/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.d.g.f.cb
 *  d.c.a.d.g.f.za
 *  d.c.a.d.h.b.j3
 *  java.lang.Object
 */
package d.c.a.d.h.b;

import d.c.a.d.g.f.cb;
import d.c.a.d.g.f.za;
import d.c.a.d.h.b.j3;

public final class x0
implements j3 {
    public static final j3 a = new x0();

    public final Object a() {
        return ((cb)za.f.a()).d();
    }
}

