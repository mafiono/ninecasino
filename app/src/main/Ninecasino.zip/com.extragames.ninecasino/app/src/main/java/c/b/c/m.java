/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.b.h.f0
 *  c.b.h.f0$a
 *  java.lang.Object
 */
package c.b.c;

import c.b.c.k;
import c.b.h.f0;

public class m
implements f0.a {
    public final /* synthetic */ k a;

    public m(k k2) {
        this.a = k2;
    }
}

