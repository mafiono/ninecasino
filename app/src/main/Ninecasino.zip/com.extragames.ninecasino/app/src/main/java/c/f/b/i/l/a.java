/*
 * Decompiled with CFR 0.0.
 */
package c.f.b.i.l;

import c.f.b.i.l.g;
import c.f.b.i.l.m;

public class a
extends g {
    public a(m m2) {
        super(m2);
    }
}

