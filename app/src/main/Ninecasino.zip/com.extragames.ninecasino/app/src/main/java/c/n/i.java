/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.n.f
 *  c.n.f$a
 *  c.n.j
 *  c.n.k
 *  java.lang.Object
 */
package c.n;

import c.n.f;
import c.n.j;
import c.n.k;

public interface i
extends j {
    void d(k var1, f.a var2);
}

