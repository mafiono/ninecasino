/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.d.g.f.ha
 *  d.c.a.d.g.f.ka
 *  d.c.a.d.h.b.j3
 *  java.lang.Object
 */
package d.c.a.d.h.b;

import d.c.a.d.g.f.ha;
import d.c.a.d.g.f.ka;
import d.c.a.d.h.b.j3;

public final class r2
implements j3 {
    public static final j3 a = new r2();

    public final Object a() {
        return ((ka)ha.f.a()).d();
    }
}

