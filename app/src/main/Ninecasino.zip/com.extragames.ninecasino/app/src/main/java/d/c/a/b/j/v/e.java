/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.System
 */
package d.c.a.b.j.v;

import d.c.a.b.j.v.a;

public class e
implements a {
    @Override
    public long a() {
        return System.currentTimeMillis();
    }
}

