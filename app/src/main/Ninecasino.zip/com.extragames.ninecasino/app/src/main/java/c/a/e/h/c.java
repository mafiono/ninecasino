/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  c.a.e.h.a
 *  java.lang.Object
 */
package c.a.e.h;

import android.content.Context;
import android.content.Intent;
import c.a.e.h.a;

public final class c
extends a<Intent, c.a.e.a> {
    public Intent a(Context context, Object object) {
        return (Intent)object;
    }

    public Object c(int n2, Intent intent) {
        return new c.a.e.a(n2, intent);
    }
}

