/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.n.w
 *  c.n.x
 *  c.n.z
 *  java.lang.Class
 *  java.lang.String
 */
package c.n;

import c.n.w;
import c.n.x;
import c.n.z;

public abstract class y
extends z
implements x {
    public abstract <T extends w> T a(String var1, Class<T> var2);
}

