/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c.h.c.a
 */
package c.h.b;

import c.h.c.a;

public class c
extends a {
    public static final /* synthetic */ int b;
}

