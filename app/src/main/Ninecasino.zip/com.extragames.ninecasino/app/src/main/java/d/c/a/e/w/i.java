/*
 * Decompiled with CFR 0.0.
 */
package d.c.a.e.w;

import d.c.a.e.w.d;
import d.c.a.e.w.m;

public class i
extends d {
    @Override
    public void a(m m2, float f2, float f3, float f5) {
        m2.e(0.0f, f5 * f3, 180.0f, 180.0f - f2);
        float f8 = f3 * (f5 * 2.0f);
        m2.a(0.0f, 0.0f, f8, f8, 180.0f, f2);
    }
}

