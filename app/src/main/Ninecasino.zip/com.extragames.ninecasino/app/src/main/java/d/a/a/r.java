/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.d.j.c
 *  d.c.a.d.j.h
 *  f.m.d
 *  f.o.b.i
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 */
package d.a.a;

import d.c.a.d.j.c;
import d.c.a.d.j.h;
import d.c.b.y.g;
import f.m.d;
import f.o.b.i;

public final class r<TResult>
implements c<Boolean> {
    public final /* synthetic */ g a;
    public final /* synthetic */ d b;

    public r(g g2, d d2) {
        this.a = g2;
        this.b = d2;
    }

    public final void a(h<Boolean> h2) {
        d d2;
        g g2;
        i.e(h2, (String)"task");
        if (h2.n()) {
            d2 = this.b;
            g2 = this.a;
        } else {
            d2 = this.b;
            g2 = null;
        }
        d2.g((Object)g2);
    }
}

