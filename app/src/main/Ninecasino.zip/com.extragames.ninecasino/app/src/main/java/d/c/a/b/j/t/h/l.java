/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.c.a.b.j.i
 *  d.c.a.b.j.t.h.m
 *  d.c.a.b.j.t.h.s
 *  java.lang.Object
 */
package d.c.a.b.j.t.h;

import d.c.a.b.j.i;
import d.c.a.b.j.t.h.m;
import d.c.a.b.j.t.h.s;
import d.c.a.b.j.u.b;

public final class l
implements b.a {
    public final m a;
    public final i b;
    public final int c;

    public l(m m2, i i2, int n2) {
        this.a = m2;
        this.b = i2;
        this.c = n2;
    }

    public Object execute() {
        m m2 = this.a;
        i i2 = this.b;
        int n2 = this.c;
        m2.d.a(i2, n2 + 1);
        return null;
    }
}

