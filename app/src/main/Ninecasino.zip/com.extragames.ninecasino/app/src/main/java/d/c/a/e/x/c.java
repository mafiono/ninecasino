/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  java.lang.Object
 */
package d.c.a.e.x;

import android.view.View;

public interface c {
    void a(View var1, int var2, int var3, int var4, int var5);
}

