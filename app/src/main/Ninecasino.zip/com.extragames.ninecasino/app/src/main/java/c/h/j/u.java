/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  c.h.j.t
 *  java.lang.Object
 */
package c.h.j;

import android.view.View;
import c.h.j.t;

public class u
implements t {
    public void b(View view) {
    }

    public void c(View view) {
    }
}

