/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package d.c.a.b.j.r.a;

public final class b<T>
implements Object<T>,
Object<T> {
    public final T a;

    public b(T t2) {
        this.a = t2;
    }

    public T get() {
        return this.a;
    }
}

