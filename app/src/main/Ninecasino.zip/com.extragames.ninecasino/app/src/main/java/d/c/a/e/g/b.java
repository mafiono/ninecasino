/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.material.bottomsheet.BottomSheetBehavior
 *  java.lang.Object
 */
package d.c.a.e.g;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import d.c.a.e.r.m;

public class b
implements m {
    public final /* synthetic */ BottomSheetBehavior a;

    public b(BottomSheetBehavior bottomSheetBehavior) {
        this.a = bottomSheetBehavior;
    }
}

