/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.SystemClock
 *  java.lang.Object
 */
package d.c.a.b.j.v;

import android.os.SystemClock;
import d.c.a.b.j.v.a;

public class d
implements a {
    @Override
    public long a() {
        return SystemClock.elapsedRealtime();
    }
}

