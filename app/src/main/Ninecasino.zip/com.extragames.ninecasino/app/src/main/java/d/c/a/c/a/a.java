/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.IInterface
 *  java.lang.Object
 */
package d.c.a.c.a;

import android.os.Bundle;
import android.os.IInterface;

public interface a
extends IInterface {
    Bundle u(Bundle var1);
}

